-- -----------------------------------------------------
-- Table CEP
-- -----------------------------------------------------
DROP TABLE IF EXISTS CEP ;

CREATE TABLE IF NOT EXISTS CEP (
  CEP INTEGER NOT NULL,
  estado VARCHAR(45) NULL,
  município VARCHAR(45) NULL,
  PRIMARY KEY (CEP))
;


-- -----------------------------------------------------
-- Table Funcionário
-- -----------------------------------------------------
DROP TABLE IF EXISTS Funcionário ;

CREATE TABLE IF NOT EXISTS Funcionário (
  idFuncionário INTEGER NOT NULL,
  email VARCHAR(80) NULL,
  senha VARCHAR(45) NULL,
  complemento VARCHAR(45) NULL,
  número INTEGER NULL,
  salário DOUBLE NULL,
  horas_extras FLOAT NULL,
  produtividade INTEGER NULL,
  rua VARCHAR(45) NULL,
  bairro VARCHAR(45) NULL,
  cpf VARCHAR(45) NULL,
  nome VARCHAR(45) NULL,
  função VARCHAR(45) NULL,
  CEP INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário, CEP),
  CONSTRAINT fk_Funcionário_CEP1
    FOREIGN KEY (CEP)
    REFERENCES CEP (CEP)
    
    )
;

CREATE INDEX fk_Funcionário_CEP1_idx ON Funcionário (CEP ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Gestor_Compra
-- -----------------------------------------------------
DROP TABLE IF EXISTS Gestor_Compra ;

CREATE TABLE IF NOT EXISTS Gestor_Compra (
  habilidade VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário),
  CONSTRAINT fk_Gestor_Compra_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;


-- -----------------------------------------------------
-- Table Fornecedor
-- -----------------------------------------------------
DROP TABLE IF EXISTS Fornecedor ;

CREATE TABLE IF NOT EXISTS Fornecedor (
  idFornecedor INTEGER NOT NULL,
  nome VARCHAR(45) NULL,
  email VARCHAR(45) NULL,
  bairro VARCHAR(45) NULL,
  rua VARCHAR(45) NULL,
  complemento VARCHAR(45) NULL,
  número INTEGER NULL,
  idFuncionário INTEGER NOT NULL,
  CEP INTEGER NOT NULL,
  CNPJ INTEGER NOT NULL,
  PRIMARY KEY (idFornecedor),
  CONSTRAINT fk_Fornecedor_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    ,
  CONSTRAINT fk_Fornecedor_CEP.Fornecedor1
    FOREIGN KEY (CEP)
    REFERENCES CEP (CEP)
    
    )
;

CREATE INDEX fk_Fornecedor_Funcionário1_idx ON Fornecedor (idFuncionário ASC) VISIBLE;

CREATE INDEX fk_Fornecedor_CEP.Fornecedor1_idx ON Fornecedor (CEP ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Compra
-- -----------------------------------------------------
DROP TABLE IF EXISTS Compra ;

CREATE TABLE IF NOT EXISTS Compra (
  nota_fiscal INTEGER NOT NULL,
  data DATETIME NULL,
  total_comprado DOUBLE NULL,
  hora INTEGER NULL,
  idFuncionário INTEGER NOT NULL,
  idFornecedor INTEGER NOT NULL,
  PRIMARY KEY (nota_fiscal),
  CONSTRAINT fk_Compra_Gestor_Compra1
    FOREIGN KEY (idFuncionário)
    REFERENCES Gestor_Compra (idFuncionário)
    
    ,
  CONSTRAINT fk_Compra_Fornecedor1
    FOREIGN KEY (idFornecedor)
    REFERENCES Fornecedor (idFornecedor)
    
    )
;

CREATE INDEX fk_Compra_Gestor_Compra1_idx ON Compra (idFuncionário ASC) VISIBLE;

CREATE INDEX fk_Compra_Fornecedor1_idx ON Compra (idFornecedor ASC) VISIBLE;


-- -----------------------------------------------------
-- Table timestamps
-- -----------------------------------------------------
DROP TABLE IF EXISTS timestamps ;

CREATE TABLE IF NOT EXISTS timestamps (
  create_time TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  update_time TIMESTAMP NULL);


-- -----------------------------------------------------
-- Table Cliente
-- -----------------------------------------------------
DROP TABLE IF EXISTS Cliente ;

CREATE TABLE IF NOT EXISTS Cliente (
  idCliente INTEGER NOT NULL,
  nome VARCHAR(45) NULL,
  complemento VARCHAR(45) NULL,
  número VARCHAR(45) NULL,
  é_físico TINYINTEGER NULL,
  é_jurídico TINYINTEGER NULL,
  CEP INTEGER NOT NULL,
  PRIMARY KEY (idCliente, CEP),
  CONSTRAINT fk_Cliente_CEP1
    FOREIGN KEY (CEP)
    REFERENCES CEP (CEP)
    
    )
;

CREATE INDEX fk_Cliente_CEP1_idx ON Cliente (CEP ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Vendedor
-- -----------------------------------------------------
DROP TABLE IF EXISTS Vendedor ;

CREATE TABLE IF NOT EXISTS Vendedor (
  sommelies INTEGER NOT NULL,
  idFuncionário INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário),
  CONSTRAINT fk_Vendedor_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;


-- -----------------------------------------------------
-- Table Motorista
-- -----------------------------------------------------
DROP TABLE IF EXISTS Motorista ;

CREATE TABLE IF NOT EXISTS Motorista (
  CNH INTEGER NOT NULL,
  nome VARCHAR(45) NULL,
  PRIMARY KEY (CNH))
;


-- -----------------------------------------------------
-- Table Trajeto
-- -----------------------------------------------------
DROP TABLE IF EXISTS Trajeto ;

CREATE TABLE IF NOT EXISTS Trajeto (
  cód_trajeto INTEGER NOT NULL,
  distância FLOAT NULL,
  PRIMARY KEY (cód_trajeto))
;


-- -----------------------------------------------------
-- Table Veículo
-- -----------------------------------------------------
DROP TABLE IF EXISTS Veículo ;

CREATE TABLE IF NOT EXISTS Veículo (
  placa INTEGER NOT NULL,
  disbonibilidade TINYINTEGER NULL,
  capacidade_carga VARCHAR(45) NULL,
  consumo VARCHAR(45) NULL,
  km_rodado INTEGER NULL,
  fabricação VARCHAR(45) NULL,
  PRIMARY KEY (placa))
;


-- -----------------------------------------------------
-- Table Gestor_Entrega
-- -----------------------------------------------------
DROP TABLE IF EXISTS Gestor_Entrega ;

CREATE TABLE IF NOT EXISTS Gestor_Entrega (
  habilidade VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário),
  CONSTRAINT fk_Gestor_Compra_Funcionário101
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;


-- -----------------------------------------------------
-- Table Entrega
-- -----------------------------------------------------
DROP TABLE IF EXISTS Entrega ;

CREATE TABLE IF NOT EXISTS Entrega (
  cód_entrega INTEGER NOT NULL,
  CNH INTEGER NOT NULL,
  cód_trajeto INTEGER NOT NULL,
  placa INTEGER NOT NULL,
  pto_saída VARCHAR(45) NULL,
  pto_chegada VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  horário_entrega DATETIME NULL,
  PRIMARY KEY (cód_entrega),
  CONSTRAINT fk_Entrega_Motorista1
    FOREIGN KEY (CNH)
    REFERENCES Motorista (CNH)
    
    ,
  CONSTRAINT fk_Entrega_Trajeto1
    FOREIGN KEY (cód_trajeto)
    REFERENCES Trajeto (cód_trajeto)
    
    ,
  CONSTRAINT fk_Entrega_Veículo1
    FOREIGN KEY (placa)
    REFERENCES Veículo (placa)
    
    ,
  CONSTRAINT fk_Entrega_Gestor_Entrega1
    FOREIGN KEY (idFuncionário)
    REFERENCES Gestor_Entrega (idFuncionário)
    
    )
;

CREATE INDEX fk_Entrega_Motorista1_idx ON Entrega (CNH ASC) VISIBLE;

CREATE INDEX fk_Entrega_Trajeto1_idx ON Entrega (cód_trajeto ASC) VISIBLE;

CREATE INDEX fk_Entrega_Veículo1_idx ON Entrega (placa ASC) VISIBLE;

CREATE INDEX fk_Entrega_Gestor_Entrega1_idx ON Entrega (idFuncionário ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Venda
-- -----------------------------------------------------
DROP TABLE IF EXISTS Venda ;

CREATE TABLE IF NOT EXISTS Venda (
  nota_fiscal INTEGER NOT NULL,
  data DATETIME NULL,
  hora INTEGER NULL,
  total_compra DECIMAL NULL,
  idFuncionário INTEGER NOT NULL,
  idCliente INTEGER NOT NULL,
  cód_entrega INTEGER NOT NULL,
  PRIMARY KEY (nota_fiscal),
  CONSTRAINT fk_Venda_Vendedor1
    FOREIGN KEY (idFuncionário)
    REFERENCES Vendedor (idFuncionário)
    
    ,
  CONSTRAINT fk_Venda_Cliente1
    FOREIGN KEY (idCliente)
    REFERENCES Cliente (idCliente)
    
    ,
  CONSTRAINT fk_Venda_Entrega1
    FOREIGN KEY (cód_entrega)
    REFERENCES Entrega (cód_entrega)
    
    )
;

CREATE INDEX fk_Venda_Vendedor1_idx ON Venda (idFuncionário ASC) VISIBLE;

CREATE INDEX fk_Venda_Cliente1_idx ON Venda (idCliente ASC) VISIBLE;

CREATE INDEX fk_Venda_Entrega1_idx ON Venda (cód_entrega ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Pagamento
-- -----------------------------------------------------
DROP TABLE IF EXISTS Pagamento ;

CREATE TABLE IF NOT EXISTS Pagamento (
  cód_pagamento INTEGER NOT NULL,
  valor DOUBLE NULL,
  data DATETIME NULL,
  hora DATETIME NULL,
  Funcionário INTEGER NOT NULL,
  PRIMARY KEY (cód_pagamento),
  CONSTRAINT fk_Pagamento_Funcionário1
    FOREIGN KEY (Funcionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;

CREATE INDEX fk_Pagamento_Funcionário1_idx ON Pagamento (Funcionário ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Gestor_Estoque
-- -----------------------------------------------------
DROP TABLE IF EXISTS Gestor_Estoque ;

CREATE TABLE IF NOT EXISTS Gestor_Estoque (
  habilidade VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário),
  CONSTRAINT fk_Gestor_Estoque_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;

CREATE INDEX fk_Gestor_Estoque_Funcionário1_idx ON Gestor_Estoque (idFuncionário ASC) VISIBLE;


-- -----------------------------------------------------
-- Table produto
-- -----------------------------------------------------
DROP TABLE IF EXISTS produto ;

CREATE TABLE IF NOT EXISTS produto (
  idproduto INTEGER NOT NULL,
  nome VARCHAR(45) NULL,
  lote INTEGER NULL,
  descrição VARCHAR(45) NULL,
  teor_alcóolico DECIMAL NULL,
  quantidade_estoque INTEGER NULL,
  unidade VARCHAR(45) NULL,
  tipo_alcoolico VARCHAR(45) NULL,
  categoria VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  idFornecedor INTEGER NOT NULL,
  PRIMARY KEY (idproduto),
  CONSTRAINT fk_produto_Gestor_Estoque1
    FOREIGN KEY (idFuncionário)
    REFERENCES Gestor_Estoque (idFuncionário)
    
    ,
  CONSTRAINT fk_produto_Fornecedor1
    FOREIGN KEY (idFornecedor)
    REFERENCES Fornecedor (idFornecedor)
    
    )
;

CREATE INDEX fk_produto_Gestor_Estoque1_idx ON produto (idFuncionário ASC) VISIBLE;

CREATE INDEX fk_produto_Fornecedor1_idx ON produto (idFornecedor ASC) VISIBLE;


-- -----------------------------------------------------
-- Table item_comprado
-- -----------------------------------------------------
DROP TABLE IF EXISTS item_comprado ;

CREATE TABLE IF NOT EXISTS item_comprado (
  cont INTEGER NOT NULL,
  preço_unitário DECIMAL NULL,
  quantidade INTEGER NULL,
  nota_fiscal INTEGER NOT NULL,
  idProduto INTEGER NOT NULL,
  PRIMARY KEY (cont, nota_fiscal, idProduto),
  CONSTRAINT fk_item_comprado_Compra1
    FOREIGN KEY (nota_fiscal)
    REFERENCES Compra (nota_fiscal)
    
    ,
  CONSTRAINT fk_item_comprado_produto1
    FOREIGN KEY (idProduto)
    REFERENCES produto (idproduto)
    
    )
;

CREATE INDEX fk_item_comprado_Compra1_idx ON item_comprado (nota_fiscal ASC) VISIBLE;

CREATE INDEX fk_item_comprado_produto1_idx ON item_comprado (idProduto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table item_vendido
-- -----------------------------------------------------
DROP TABLE IF EXISTS item_vendido ;

CREATE TABLE IF NOT EXISTS item_vendido (
  cont INTEGER NOT NULL,
  quantidade INTEGER NULL,
  nota_fiscal INTEGER NOT NULL,
  idProduto INTEGER NOT NULL,
  preço_unitário DECIMAL NULL,
  PRIMARY KEY (cont, nota_fiscal, idProduto),
  CONSTRAINT fk_item_vendido_Venda1
    FOREIGN KEY (nota_fiscal)
    REFERENCES Venda (nota_fiscal)
    
    ,
  CONSTRAINT fk_item_vendido_produto1
    FOREIGN KEY (idProduto)
    REFERENCES produto (idproduto)
    
    )
;

CREATE INDEX fk_item_vendido_Venda1_idx ON item_vendido (nota_fiscal ASC) VISIBLE;

CREATE INDEX fk_item_vendido_produto1_idx ON item_vendido (idProduto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Paradas_trajeto
-- -----------------------------------------------------
DROP TABLE IF EXISTS Paradas_trajeto ;

CREATE TABLE IF NOT EXISTS Paradas_trajeto (
  cont INTEGER NOT NULL,
  motivo VARCHAR(45) NULL,
  cód_trajeto INTEGER NOT NULL,
  PRIMARY KEY (cont, cód_trajeto),
  CONSTRAINT fk_Paradas_trajeto_Trajeto1
    FOREIGN KEY (cód_trajeto)
    REFERENCES Trajeto (cód_trajeto)
    
    )
;

CREATE INDEX fk_Paradas_trajeto_Trajeto1_idx ON Paradas_trajeto (cód_trajeto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Apoio_trajeto
-- -----------------------------------------------------
DROP TABLE IF EXISTS Apoio_trajeto ;

CREATE TABLE IF NOT EXISTS Apoio_trajeto (
  cont INTEGER NOT NULL,
  apoio_trajeto VARCHAR(45) NULL,
  cód_trajeto INTEGER NOT NULL,
  PRIMARY KEY (cont, cód_trajeto),
  CONSTRAINT fk_Paradas_trajeto_Trajeto10
    FOREIGN KEY (cód_trajeto)
    REFERENCES Trajeto (cód_trajeto)
    
    )
;

CREATE INDEX fk_Paradas_trajeto_Trajeto1_idx ON Apoio_trajeto (cód_trajeto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Produto.Não.Alcoolicos
-- -----------------------------------------------------
DROP TABLE IF EXISTS Produto.Não.Alcoolicos ;

CREATE TABLE IF NOT EXISTS Produto.Não.Alcoolicos (
  aroma INTEGER NOT NULL,
  idProduto INTEGER NOT NULL,
  PRIMARY KEY (idProduto),
  CONSTRAINT fk_Produto.Não.Alcoolicos_produto1
    FOREIGN KEY (idProduto)
    REFERENCES produto (idproduto)
    
    )
;

CREATE INDEX fk_Produto.Não.Alcoolicos_produto1_idx ON Produto.Não.Alcoolicos (idProduto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Produto_Alcoolicos
-- -----------------------------------------------------
DROP TABLE IF EXISTS Produto_Alcoolicos ;

CREATE TABLE IF NOT EXISTS Produto_Alcoolicos (
  aroma INTEGER NOT NULL,
  idProduto INTEGER NOT NULL,
  PRIMARY KEY (idProduto),
  CONSTRAINT fk_Produto.Não.Alcoolicos_produto10
    FOREIGN KEY (idProduto)
    REFERENCES produto (idproduto)
    
    )
;

CREATE INDEX fk_Produto.Não.Alcoolicos_produto1_idx ON Produto_Alcoolicos (idProduto ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Pessoa Física
-- -----------------------------------------------------
DROP TABLE IF EXISTS Pessoa Física ;

CREATE TABLE IF NOT EXISTS Pessoa Física (
  CPF VARCHAR(45) NOT NULL,
  idCliente INTEGER NOT NULL,
  PRIMARY KEY (idCliente),
  CONSTRAINT fk_Pessoa Física_Cliente1
    FOREIGN KEY (idCliente)
    REFERENCES Cliente (idCliente)
    
    )
;

CREATE INDEX fk_Pessoa Física_Cliente1_idx ON Pessoa Física (idCliente ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Pessoa Jurídica
-- -----------------------------------------------------
DROP TABLE IF EXISTS Pessoa Jurídica ;

CREATE TABLE IF NOT EXISTS Pessoa Jurídica (
  CNPJ VARCHAR(45) NOT NULL,
  idCliente INTEGER NOT NULL,
  PRIMARY KEY (idCliente),
  CONSTRAINT fk_Pessoa Física_Cliente10
    FOREIGN KEY (idCliente)
    REFERENCES Cliente (idCliente)
    
    )
;

CREATE INDEX fk_Pessoa Física_Cliente1_idx ON Pessoa Jurídica (idCliente ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Telefone_Func
-- -----------------------------------------------------
DROP TABLE IF EXISTS Telefone_Func ;

CREATE TABLE IF NOT EXISTS Telefone_Func (
  Telefone VARCHAR(45) NOT NULL,
  cont INTEGER NOT NULL,
  idFuncionário INTEGER NOT NULL,
  PRIMARY KEY (cont, idFuncionário, Telefone),
  CONSTRAINT fk_Telefone_Func_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    )
;

CREATE INDEX fk_Telefone_Func_Funcionário1_idx ON Telefone_Func (idFuncionário ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Telefone_Fornec
-- -----------------------------------------------------
DROP TABLE IF EXISTS Telefone_Fornec ;

CREATE TABLE IF NOT EXISTS Telefone_Fornec (
  Telefone VARCHAR(45) NOT NULL,
  cont INTEGER NOT NULL,
  idFornecedor INTEGER NOT NULL,
  PRIMARY KEY (cont, idFornecedor, Telefone),
  CONSTRAINT fk_Telefone_Fornec_Fornecedor1
    FOREIGN KEY (idFornecedor)
    REFERENCES Fornecedor (idFornecedor)
    
    )
;

CREATE INDEX fk_Telefone_Fornec_Fornecedor1_idx ON Telefone_Fornec (idFornecedor ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Telefone_Cliente
-- -----------------------------------------------------
DROP TABLE IF EXISTS Telefone_Cliente ;

CREATE TABLE IF NOT EXISTS Telefone_Cliente (
  Telefone VARCHAR(45) NOT NULL,
  cont INTEGER NOT NULL,
  idCliente INTEGER NOT NULL,
  PRIMARY KEY (cont, idCliente, Telefone),
  CONSTRAINT fk_Telefone_Fornec_copy1_Cliente1
    FOREIGN KEY (idCliente)
    REFERENCES Cliente (idCliente)
    
    )
;

CREATE INDEX fk_Telefone_Fornec_copy1_Cliente1_idx ON Telefone_Cliente (idCliente ASC) VISIBLE;


-- -----------------------------------------------------
-- Table Gestor_Vendas
-- -----------------------------------------------------
DROP TABLE IF EXISTS Gestor_Vendas ;

CREATE TABLE IF NOT EXISTS Gestor_Vendas (
  habilidade VARCHAR(45) NULL,
  idFuncionário INTEGER NOT NULL,
  idCliente INTEGER NOT NULL,
  PRIMARY KEY (idFuncionário, idCliente),
  CONSTRAINT fk_Gestor_Vendas_Funcionário1
    FOREIGN KEY (idFuncionário)
    REFERENCES Funcionário (idFuncionário)
    
    ,
  CONSTRAINT fk_Gestor_Vendas_Cliente1
    FOREIGN KEY (idCliente)
    REFERENCES Cliente (idCliente)
    
    )
;

CREATE INDEX fk_Gestor_Vendas_Cliente1_idx ON Gestor_Vendas (idCliente ASC) VISIBLE;