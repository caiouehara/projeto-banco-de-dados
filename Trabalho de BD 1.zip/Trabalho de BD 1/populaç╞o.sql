/* Trajeto
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 79);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 137);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 287);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 398);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 37);
*/

/* Apoio Trajeto
INSERT INTO apoio_trajeto
    VALUES
        (0, 'Frango Assado', 3),
        (1, 'Posto SHELL', 3),
        (2, 'Policia Rodoviária', 3),

        (0, 'Posto Graal', 4),
        (1, 'Lojinha do Amilson', 4),
        (2, 'Telefone SOS', 4),

        (0, 'Borracharia do Zé', 5),
        (1, 'Vilarejo Sol de Minas', 5),
        (2, 'Posto SHELL', 5),

        (0, 'Frango Assado', 6),
        (1, 'Policia Rodoviária', 6),
        (2, 'Telefone Assado', 6),

        (0, 'Posto Graal', 7),
        (1, 'Policia Rodoviária', 7),
        (2, 'Frango Assado', 7);
*/

/* Paradas Trajeto
INSERT INTO paradas_trajeto
    VALUES
        (0, 'Falta de Gasolina', 3),
        (0, 'Estouro do Pneu', 3),
        (0, 'Posto Graal', 7),
*/

/* Paradas Trajeto
INSERT INTO paradas_trajeto
    VALUES
        (0, 'Falta de Gasolina', 3),
        (0, 'Estouro do Pneu', 3),
        (0, 'Posto Graal', 7),
*/

/* Motorista
INSERT INTO motorista
    VALUES
        (983363, 'Radeu'),
        (193955, 'Nokeniu'),
        (447634, 'Lipur'),
        (522424, 'Irci'),
        (174551, 'Gotun');
*/

/* CEP
INSERT INTO CEP
    VALUES
         (97545690, 'SP', 'Ribeirão Preto'),
         (77001024, 'SP', 'Paranavaí'),
         (69908668, 'SP', 'Bagé'),
         (54762335, 'SP', 'Nova Friburgo'),
         (25011300, 'SP', 'Ariquemes');
*/

/* funcionário
INSERT INTO funcionário
    VALUES
        (NEXTVAL('idfuncionário_seq'), 'grunt1234@tubidu.com', '1123', 'ap41', 243, 1200.00, 30, 5, 'Av. Casarão', 'Jardim Alto', '742.637.570-68', 'Rodolfo', 'Responsável pela Ambev', 97545690, 'g_compra'),
        (NEXTVAL('idfuncionário_seq'), 'furrkkyy@coughone.com', 'login123', 'prédio 1, ap25', 301, 2743.35, 20, 6, 'Av. do Café', 'Monte Alegre', '265.056.450-47', 'Eliseu', 'Responsável pelo estado SP', 77001024, 'g_entrega'),
        (NEXTVAL('idfuncionário_seq'), 'salocaffv4r@checkwilez.com', 'pass2131', 'bloco C, casa 43', 1305, 1200.00, 30, 4, 'Rua Doutor Thirso', 'Vila Olímpia', '147.627.650-15', 'Maria Clara', 'Responsável pelo CDD principal de SP',69908668, 'g_estoque'),
        (NEXTVAL('idfuncionário_seq'), 'bc722@aliexchangevn.com', 'oie123', '', 35, 2500.00, 25, 8, 'Rua Estela', 'Mascote', '569.579.590-74', 'Afonso',  'Gerente Oficial do Estado de SP', 54762335, 'g_vendas'),
        (NEXTVAL('idfuncionário_seq'), 'vito1994@spacepush.org', 'senha', '', 204, 1350.34, 25, 7, 'Rua Santa Maria', 'Teixeira', '150.075.380-78', 'Clarice','Vendedor Oficial do Estado de SP', 25011300 ,'vendedor');
*/

/* Veículo
INSERT INTO veículo
    VALUES
        (4763, 1, '500kg', '5km/L', 310, 'MAN'),
        (6912, 1, '150kg', '10km/L', 2020, 'Agrale'),
        (8713, 1, '300kg', '12km/L', 190, 'Peterbilt'),
        (9135, 0, '350kg', '8km/L', 10, 'International'),
        (9913, 0, '400kg', '5,5km/L', 5510, 'Volvo');
*/

/* Gestor Entrega
INSERT INTO CEP
    VALUES
             (36111588, 'SP', 'Vila Jesus');

INSERT INTO funcionário
    VALUES
    (NEXTVAL('idfuncionário_seq'), 'andrealmeida@spacepush.org', '1234', '', 3123, 1487.34, 120, 8, 'Rua São Joséa', 'Vila Mariana', '180.035.310-97', 'Andre','Gestor de frota SP', 36111588 ,'g_entrega');

INSERT INTO gestor_entrega
    VALUES
      ('Bom negociador', 1),
      ('Possui bons contatos', 5);
*/


/* Entrega
INSERT INTO entrega
    VALUES
        (0, 983363, 3, 4763, 'Ribeirão Preto', 'São Carlos', 1, '2022-11-19 10:23:54'),
        (1, 193955, 4, 6912, 'Ribeirão Preto', 'São Carlos', 1, '2022-11-30 18:46:46'),
        (2, 447634, 5, 8713, 'São Paulo', 'Araraquara', 1, '2023-1-3 06:11:31'),
        (3, 522424, 6, 9135, 'São Paulo', 'Uberaba', 5, '2023-1-6 17:50:13'),
        (4, 174551, 7, 9913, 'Ribeirão Preto', 'Sertãozinho', 5, '2023-2-4 23:16:23');
*/

/* Cliente
INSERT INTO CEP
  VALUES
  (59146425, 'AC', 'Rio Branco'),
  (78065670, 'MT', 'Cuiabá'),
  (19033130, 'SP', 'Presidente Prudente'),
  (03188060, 'SP', 'São Paulo'),
  (07809160, 'SP', 'Franco da Rocha');


INSERT INTO cliente
    VALUES
        (NEXTVAL('idcliente_seq'), 'Alexandre', 'ap48', 3, 0, 1, 59146425),
        (NEXTVAL('idcliente_seq'), 'Pedro', 'ap18', 10, 1, 0, 78065670),
        (NEXTVAL('idcliente_seq'), 'Julia', 'ap36', 512, 1, 0, 19033130),
        (NEXTVAL('idcliente_seq'), 'Fernanda', 'ap502', 210, 0, 1, 03188060),
        (NEXTVAL('idcliente_seq'), 'Caio', '', 1012, 1, 1, 07809160);
*/


/* Fornecedor
INSERT INTO CEP
  VALUES
  (19450970, 'SP', 'Vila Pontilhão'),
  (07801060, 'SE', 'Aeroporto'),
  (06626050, 'DF', 'Setor Sudoeste'),
  (14094161, 'SP', 'São Paulo'),
  (01014916, 'SP', 'João Pessoa');


INSERT INTO CEP
  VALUES
  (72317513, 'SP', 'Samambaia Sul (Samambaia)');

INSERT INTO funcionário
    VALUES
        (6, 'kzavalina@jucky.net', 'testeteste', '', 122, 2750.00, 12, 8, 'Conjunto Cidade Nova III', 'Cidade Nova', '752.194.080-62', 'Cláudio',  'Responsável pela Coca-Cola', 72317513, 'g_compra');

INSERT INTO gestor_compra
  VALUES
    ('Bem relacionado', 3),
    ('Não se estressa por nada', 6);

INSERT INTO Fornecedor
  VALUES
    (NEXTVAL('idfornecedor_seq'), 'Pedro', 'kzavalina@jucky.net', 'Santo Amaro', 'Rua Aliseu Domingues', '', 207,  3, 19450970, 981896),
    (NEXTVAL('idfornecedor_seq'), 'João', 'joãsoofical@jucky.net', 'Machado', 'Rua Topázio', '', 3210,  3, 07801060, 316052),
    (NEXTVAL('idfornecedor_seq'), 'Alemida', 'almeidinha123@jucky.net', 'Cidade Universitária Pedra Branca', 'Quadra 1007 Sul Alameda 17', '', 1202,  6, 06626050, 751337),
    (NEXTVAL('idfornecedor_seq'), 'Letícia', 'lelet@jucky.net', 'Canoas', 'Rua José Alencar', '', 150,  6, 14094161, 183640),
    (NEXTVAL('idfornecedor_seq'), 'Cláudia', 'claduiaprofissional@jucky.net', 'Núcleo Industrial', 'Vila Bispo', '', 11,  6, 01014916, 759785);
*/
