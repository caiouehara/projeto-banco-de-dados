/* Trajeto
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 79);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 137);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 287);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 398);
INSERT INTO trajeto VALUES (NEXTVAL('cód_trajeto_seq'), 37);
*/

/* Apoio Trajeto
INSERT INTO apoio_trajeto
    VALUES
        (0, 'Frango Assado', 3),
        (1, 'Posto SHELL', 3),
        (2, 'Policia Rodoviária', 3),

        (0, 'Posto Graal', 4),
        (1, 'Lojinha do Amilson', 4),
        (2, 'Telefone SOS', 4),

        (0, 'Borracharia do Zé', 5),
        (1, 'Vilarejo Sol de Minas', 5),
        (2, 'Posto SHELL', 5),

        (0, 'Frango Assado', 6),
        (1, 'Policia Rodoviária', 6),
        (2, 'Telefone Assado', 6),

        (0, 'Posto Graal', 7),
        (1, 'Policia Rodoviária', 7),
        (2, 'Frango Assado', 7);
*/

/* Paradas Trajeto
INSERT INTO paradas_trajeto
    VALUES
        (0, 'Falta de Gasolina', 3),
        (0, 'Estouro do Pneu', 3),
        (0, 'Posto Graal', 7),
*/

/* Paradas Trajeto
INSERT INTO paradas_trajeto
    VALUES
        (0, 'Falta de Gasolina', 3),
        (0, 'Estouro do Pneu', 3),
        (0, 'Posto Graal', 7),
*/

/* Motorista
INSERT INTO motorista
    VALUES
        (983363, 'Radeu'),
        (193955, 'Nokeniu'),
        (447634, 'Lipur'),
        (522424, 'Irci'),
        (174551, 'Gotun');
*/

/* CEP
INSERT INTO CEP
    VALUES
         (97545690, 'SP', 'Ribeirão Preto'),
         (77001024, 'SP', 'Paranavaí'),
         (69908668, 'SP', 'Bagé'),
         (54762335, 'SP', 'Nova Friburgo'),
         (25011300, 'SP', 'Ariquemes');
*/

/* funcionário
INSERT INTO funcionário
    VALUES
        (NEXTVAL('idfuncionário_seq'), 'grunt1234@tubidu.com', '1123', 'ap41', 243, 1200.00, 30, 5, 'Av. Casarão', 'Jardim Alto', '742.637.570-68', 'Rodolfo', 'Responsável pela Ambev', 97545690, 'g_compra'),
        (NEXTVAL('idfuncionário_seq'), 'furrkkyy@coughone.com', 'login123', 'prédio 1, ap25', 301, 2743.35, 20, 6, 'Av. do Café', 'Monte Alegre', '265.056.450-47', 'Eliseu', 'Responsável pelo estado SP', 77001024, 'g_entrega'),
        (NEXTVAL('idfuncionário_seq'), 'salocaffv4r@checkwilez.com', 'pass2131', 'bloco C, casa 43', 1305, 1200.00, 30, 4, 'Rua Doutor Thirso', 'Vila Olímpia', '147.627.650-15', 'Maria Clara', 'Responsável pelo CDD principal de SP',69908668, 'g_estoque'),
        (NEXTVAL('idfuncionário_seq'), 'bc722@aliexchangevn.com', 'oie123', '', 35, 2500.00, 25, 8, 'Rua Estela', 'Mascote', '569.579.590-74', 'Afonso',  'Gerente Oficial do Estado de SP', 54762335, 'g_vendas'),
        (NEXTVAL('idfuncionário_seq'), 'vito1994@spacepush.org', 'senha', '', 204, 1350.34, 25, 7, 'Rua Santa Maria', 'Teixeira', '150.075.380-78', 'Clarice','Vendedor Oficial do Estado de SP', 25011300 ,'vendedor');
*/

/* Veículo
INSERT INTO veículo
    VALUES
        (4763, 1, '500kg', '5km/L', 310, 'MAN'),
        (6912, 1, '150kg', '10km/L', 2020, 'Agrale'),
        (8713, 1, '300kg', '12km/L', 190, 'Peterbilt'),
        (9135, 0, '350kg', '8km/L', 10, 'International'),
        (9913, 0, '400kg', '5,5km/L', 5510, 'Volvo');
*/

/* Gestor Entrega
INSERT INTO CEP
    VALUES
             (36111588, 'SP', 'Vila Jesus');

INSERT INTO funcionário
    VALUES
    (NEXTVAL('idfuncionário_seq'), 'andrealmeida@spacepush.org', '1234', '', 3123, 1487.34, 120, 8, 'Rua São Joséa', 'Vila Mariana', '180.035.310-97', 'Andre','Gestor de frota SP', 36111588 ,'g_entrega');

INSERT INTO gestor_entrega
    VALUES
      ('Bom negociador', 1),
      ('Possui bons contatos', 5);
*/


/* Entrega
INSERT INTO entrega
    VALUES
        (0, 983363, 3, 4763, 'Ribeirão Preto', 'São Carlos', 1, '2022-11-19 10:23:54'),
        (1, 193955, 4, 6912, 'Ribeirão Preto', 'São Carlos', 1, '2022-11-30 18:46:46'),
        (2, 447634, 5, 8713, 'São Paulo', 'Araraquara', 1, '2023-1-3 06:11:31'),
        (3, 522424, 6, 9135, 'São Paulo', 'Uberaba', 5, '2023-1-6 17:50:13'),
        (4, 174551, 7, 9913, 'Ribeirão Preto', 'Sertãozinho', 5, '2023-2-4 23:16:23');
*/

/* Cliente
INSERT INTO CEP
  VALUES
  (59146425, 'AC', 'Rio Branco'),
  (78065670, 'MT', 'Cuiabá'),
  (19033130, 'SP', 'Presidente Prudente'),
  (03188060, 'SP', 'São Paulo'),
  (07809160, 'SP', 'Franco da Rocha');


INSERT INTO cliente
    VALUES
        (NEXTVAL('idcliente_seq'), 'Alexandre', 'ap48', 3, 0, 1, 59146425,3),
        (NEXTVAL('idcliente_seq'), 'Pedro', 'ap18', 10, 1, 0, 78065670,3),
        (NEXTVAL('idcliente_seq'), 'Julia', 'ap36', 512, 1, 0, 19033130,3),
        (NEXTVAL('idcliente_seq'), 'Fernanda', 'ap502', 210, 0, 1, 03188060,3),
        (NEXTVAL('idcliente_seq'), 'Caio', '', 1012, 1, 1, 07809160,3);
*/


/* Fornecedor
INSERT INTO CEP
  VALUES
  (19450970, 'SP', 'Vila Pontilhão'),
  (07801060, 'SE', 'Aeroporto'),
  (06626050, 'DF', 'Setor Sudoeste'),
  (14094161, 'SP', 'São Paulo'),
  (01014916, 'SP', 'João Pessoa');


INSERT INTO CEP
  VALUES
  (72317513, 'SP', 'Samambaia Sul (Samambaia)');

INSERT INTO funcionário
    VALUES
        (6, 'kzavalina@jucky.net', 'testeteste', '', 122, 2750.00, 12, 8, 'Conjunto Cidade Nova III', 'Cidade Nova', '752.194.080-62', 'Cláudio',  'Responsável pela Coca-Cola', 72317513, 'g_compra');

INSERT INTO gestor_compra
  VALUES
    ('Bem relacionado', 3),
    ('Não se estressa por nada', 6);

INSERT INTO Fornecedor
  VALUES
    (NEXTVAL('idfornecedor_seq'), 'Pedro', 'kzavalina@jucky.net', 'Santo Amaro', 'Rua Aliseu Domingues', '', 207,  3, 19450970, 981896),
    (NEXTVAL('idfornecedor_seq'), 'João', 'joãsoofical@jucky.net', 'Machado', 'Rua Topázio', '', 3210,  3, 07801060, 316052),
    (NEXTVAL('idfornecedor_seq'), 'Alemida', 'almeidinha123@jucky.net', 'Cidade Universitária Pedra Branca', 'Quadra 1007 Sul Alameda 17', '', 1202,  6, 06626050, 751337),
    (NEXTVAL('idfornecedor_seq'), 'Letícia', 'lelet@jucky.net', 'Canoas', 'Rua José Alencar', '', 150,  6, 14094161, 183640),
    (NEXTVAL('idfornecedor_seq'), 'Cláudia', 'claduiaprofissional@jucky.net', 'Núcleo Industrial', 'Vila Bispo', '', 11,  6, 01014916, 759785);
*/

/* Compra
INSERT INTO compra
  VALUES
    (1000, '2023-01-22 17:00:01', 11550.50, 17, 3, 1),
    (1001, '2023-01-23 21:12:12', 15560.50, 21, 3, 1),
    (1002, '2023-01-27 16:45:52', 13250.50, 16, 3, 4),
    (1003, '2023-02-12 23:10:09', 114050.50, 23, 6, 2),
    (1004, '2023-02-15 09:11:10', 10120.50, 9, 6, 5);
*/

/* Gestor_Estoque
INSERT INTO gestor_estoque
    VALUES ('Organizado', 3);
*/

/* Gestor_Venda
INSERT INTO gestor_vendas
    VALUES ('Extrovertido', 3);
*/

/* Item_Comprado
INSERT INTO CEP
VALUES (45005106, 'SP', 'Praça José de Souza Carote');

INSERT INTO funcionário
VALUES
(8, 'aldemirjose123@jucky.net', 'senha222', '', 11, 1250.00, 10, 5, 'Cidade grande', 'Nova estrada', '555.154.080-62', 'Aldemir',  'Responsável pelo CDD Campinas', 45005106, 'g_estoque');

INSERT INTO gestor_estoque
    VALUES ('Eficiente', 8);

INSERT INTO produto
    VALUES
    (11, 'Coca cola', 512, 'Coca Cola Original, refrigerante', 0, 1201, '2L', 'Não', 'Refrigerante', 3 , 1),
    (12, 'Cerveja Heineken', 312, 'Heineken oficial brasileira',  6, 5021, '350ml', 'Sim', 'Cerveja', 8, 4),
    (13, 'Cerveja Budweiser', 126, 'Cerveja universitária Budweiser', 5, 4871, '1L', 'Sim', 'Cerveja', 8, 2),
    (14, 'Vodka Askov', 56, 'Vodka da fábrica Hinamoto', 20, 510, '900ml', 'Sim' , 'Destilado', 3, 3),
    (15, 'Sukita', 215, 'Da marca Coca, refrigerante sabores', 0, 3020, '1L', 'Não' , 'Refrigerante', 3, 3);

INSERT INTO item_comprado
  VALUES
    (0, 9.28, 125, 1000, 11),
    (1, 4.32, 238, 1001, 12),
    (2, 6.39, 471, 1002, 13),
    (3, 7.50, 70, 1003, 14),
    (4, 8.23, 96, 1004, 15);

*/

/* Item Vendido
INSERT INTO CEP
  VALUES
  (77016484, 'SP', 'Farolândia');

INSERT INTO funcionário (idfuncionário, email, senha, complemento, número, salário, horas_extras, produtividade, rua, bairro, cpf, nome, função, cep, tipo)
VALUES (9, 'joao.silva@gmail.com', 'senha123', 'Apartamento 301', 123, 2500.00, 5.25, 8, 'Rua das Flores', 'Centro', '123.456.789-01', 'João Silva', 'Analista de Vendas', 77016484, 'vendedor');

INSERT INTO vendedor
    VALUES 
        (4, 5),
        (8, 9);

INSERT INTO venda
  VALUES
    (4000, '2023-01-22 18:00:01', 18, 5123.50, 5, 11, 0),
    (4001, '2023-01-23 22:12:12', 22, 7100.50, 5, 11, 0),
    (4002, '2023-01-27 17:45:52', 17, 8120.50, 9, 12, 2),
    (4003, '2023-02-12 01:10:09', 01, 4444.50, 5, 14, 1),
    (4004, '2023-02-15 08:11:10', 08, 581.50, 9, 15, 2);

INSERT INTO item_vendido
  VALUES
    (0, 928, 4000, 11, 8.29),
    (1, 432, 4001, 14, 9.73),
    (2, 639, 4002, 15, 10.10),
    (3, 750, 4003, 13, 6.29),
    (4, 823, 4004, 13, 11.23);

*/

/*
INSERT INTO pagamento
  VALUES
    (NEXTVAL('cód_pagamento_seq'), 1500.06, '21/01/2023', '21/01/2023 12:00:00', 1),
    (NEXTVAL('cód_pagamento_seq'), 1200.0, '24/01/2023', '24/01/2023 12:00:00', 9),
    (NEXTVAL('cód_pagamento_seq'), 900.15, '26/01/2023', '26/01/2023 12:00:00', 7),
    (NEXTVAL('cód_pagamento_seq'), 1400.00, '28/01/2023', '28/01/2023 12:00:00', 5),
    (NEXTVAL('cód_pagamento_seq'), 1800.00, '30/01/2023', '30/01/2023 12:00:00', 2);
*/

/*
INSERT INTO paradas_entrega
  VALUES 
    (0, 'Furou o pneu', 0),
    (0, 'Acabou a gasolina', 1),
    (1, 'Problema no motor', 1),
    (0, 'Furou o pneu', 2),
    (0, 'Acabou a gasolina', 3);
*/

/*
INSERT INTO pessoa_fisica
  VALUES 
    (37414121046, 12),
    (73780978024, 13),
    (73091269043, 15 );

INSERT INTO pessoa_juridica
  VALUES 
    (13056383000161, 11),
    (42679035000149, 14),
    (20940714000197, 15 );
*/

/*
INSERT INTO produto_alcoolicos
  VALUES 
    (8, 12),
    (7, 13),
    (5, 14 );

    INSERT INTO produto_não_alcoolicos
  VALUES 
    (4, 11),
    (2, 15 );
*/    

/*
INSERT INTO telefone_cliente
  VALUES 
    ('(27) 3131-6944', 0,11),
    ('(79) 2836-6445', 1,11),
    ('(28) 3122-3463', 0,13),
    ('(22) 2041-6535', 0,14),
    ('(27) 3764-2063', 0,15),
    ('(27) 3478-4026', 1,15),
    ('(22) 2249-4010', 2,15);

INSERT INTO telefone_fornec
  VALUES 
    ('(24) 3496-7038', 0,1),
    ('(35) 2834-3072', 1,1),
    ('(95) 2113-2435', 0,2),
    ('(81) 3587-1357', 0,3),
    ('(99) 3235-1685', 0,4),
    ('(79) 2818-2790', 0,5),
    ('(15) 2437-2885', 1,5),
    ('(95) 2308-5458', 2,5);

INSERT INTO telefone_func
  VALUES 
    ('(79) 3335-8383', 0,1),
    ('(99) 3236-6153', 0,2),
    ('(44) 2371-6273', 0,3),
    ('(97) 3675-8253', 0,4),
    ('(45) 2533-8632', 0,5),
    ('(65) 3144-7436', 0,6),
    ('(99) 2311-6781', 0,7),
    ('(68) 2863-1803', 0,8),   
    ('(69) 2787-1153', 0,9),  
    ('(61) 3156-1457', 1,9), 
    ('(95) 3547-8652', 1,8), 
    ('(67) 2418-2208', 2,9);   
*/